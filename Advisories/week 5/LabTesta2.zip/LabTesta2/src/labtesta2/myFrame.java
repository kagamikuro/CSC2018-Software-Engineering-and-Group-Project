/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package labtesta2;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

class myFrame extends JFrame
{
	JButton[] b;
	JTextField[] t;
	JTextField tlast;
	int N; // number of items in the array
	myHandler H = new myHandler();


	public myFrame(int Num)
	{
		N = Num;
		/* Size of frame depends on how many button/textfield pairs there are (N)  */
		setSize(250, (N+1)*35 + 50);
		setTitle("Text Field Test");

		Container c = getContentPane();
		c.setLayout(new GridLayout(N+1,1));  // N button/text pairs, one bottom text field

    b = new JButton[N];
		t = new JTextField[N];
    for (int i=0; i<N;i++)
		{
		  b[i] = new JButton("Name "+(i+1));
		  t[i] = new JTextField(10);
		  c.add(miniPanel(b[i], t[i]));
		} // for

		tlast = new JTextField(20);
		JPanel p = new JPanel();
		p.setLayout(new FlowLayout());
		p.add(tlast);
		tlast.setBackground(Color.white);
		c.add(p);

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//pack();
		setVisible(true);

	} // myFrame constructor


	JPanel miniPanel(JButton B, JTextField T)
	// Constructs and returns a panel with given button and text field
	{
		B.addActionListener(H);
		T.setBackground(Color.white);

		JPanel p = new JPanel();
		p.setLayout(new FlowLayout());
		p.add(B);
		p.add(T);
		return p;
	}  // miniPanel method


	private class myHandler implements ActionListener
	{
		public void actionPerformed(ActionEvent e)
		{
			Object ob = e.getSource();

			for (int i=0; i<N; i++)
		  	if (ob == b[i])
				{
			  	tlast.setText(t[i].getText());
		 		} // if

		} // method actionPerformed

	} // myHandler


} // myFrame
