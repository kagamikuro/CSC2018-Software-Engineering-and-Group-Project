/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package labtesta2;

/**
 *
 * @author ioneill
 */
public class LabTesta2 {

    /**
     * @param args the command line arguments
     */
    public static void main (String args[])
	{
		myFrame f1 = new myFrame(5);
	} // main

}
