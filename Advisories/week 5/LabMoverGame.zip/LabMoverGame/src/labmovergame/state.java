/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package labmovergame;

/**
 *
 * @author ioneill
 */
class state
{
	/* A position [i][j] is either blank, blocked or the token */

	public static final int blank = 0;
	public static final int blocked = 1;
	public static final int token = 2;

	public int numRows, numCols;

	public int[][] board;
	private int tokenX, tokenY;

	private myFrame fr;  // to be updated on any change of state

	public state(int[][] base, int tX, int tY)
	{
		numRows = base.length;
		numCols = base[0].length;
		board = new int[numRows][numCols];
		for (int i=0; i<numRows; i++)
			for (int j=0; j<numCols; j++)
				board[i][j] = base[i][j];
		tokenX = tX;
		tokenY = tY;
		board[tX][tY] = token;
	} // constructor


	public void setFrame(myFrame f)
	{
		fr = f;
	} // setFrame


	public void movedown()
	{
		if ((tokenX+1 < numRows) && (board[tokenX+1][tokenY] == blank))
		{
			board[tokenX][tokenY] = blank;
			tokenX++;
			board[tokenX][tokenY] = token;
			fr.drawBoard();
		}
	}  // move down


	public void moveup()
	{
		if ((tokenX > 0) && (board[tokenX-1][tokenY] == blank))
		{
			board[tokenX][tokenY] = blank;
			tokenX--;
			board[tokenX][tokenY] = token;
			fr.drawBoard();
		}
	}  // move up


	public void moveleft()
	{
		if ((tokenY > 0) && (board[tokenX][tokenY-1] == blank))
		{
			board[tokenX][tokenY] = blank;
			tokenY--;
			board[tokenX][tokenY] = token;
			fr.drawBoard();
		}
	}  // move left


	public void moveright()
	{
		if ((tokenY+1 < numCols) && (board[tokenX][tokenY+1] == blank))
		{
			board[tokenX][tokenY] = blank;
			tokenY++;
			board[tokenX][tokenY] = token;
			fr.drawBoard();
		}
	}  // move right


} // state
