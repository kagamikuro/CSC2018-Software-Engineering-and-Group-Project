/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */



package labmovergame;

import java.awt.*;

class LabMoverGame{

/**
 *
 * @author ioneill
 */
    public static void main (String args[])
            {
                    int[][] initialBoard = { {0, 0, 0, 0, 0},
                                             {0, 1, 0, 0, 0},
                                             {0, 1, 0, 1, 0},
                                             {0, 0, 0, 1, 0},
                                             {0, 0, 0, 0, 0} };

                    state boardState = new state(initialBoard, 0, 0);

                    myFrame fr = new myFrame(boardState);
                    boardState.setFrame(fr);

                    controller C1 = new controller(boardState, "User 1", 300, 300);
                    controller C2 = new controller(boardState, "User 2", 450, 300);

            } // main

}
