/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package labmovergame;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

class myFrame extends JFrame
{
	JButton[][] b;
	int numX, numY;
	state currentState;
        ImageIcon icon = new ImageIcon("src\\labmovergame\\ship.jpg");

	public myFrame(state St)
	{
		numX = St.numRows;
		numY = St.numCols;
		currentState = St;

		setSize(80*numX, 80*numY);
		setTitle("Button Grid");
		Container c = getContentPane();
		c.setLayout(new GridLayout(numX, numY));

    b = new JButton[numX][numY];
    for (int i=0; i<numX;i++)
			for (int j=0; j<numY; j++)
			{
			  b[i][j] = new JButton("");
		  	c.add(b[i][j]);
			} // for
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);

		drawBoard();

	} // myFrame constructor


	public void drawBoard()
	{
    for (int i=0; i<numX;i++)
			for (int j=0; j<numY; j++)
			{
			  if (currentState.board[i][j]==currentState.blank)
			  {
			  	// remove any ship there might have been
			  	b[i][j].setIcon (null);
					b[i][j].setBackground(Color.lightGray);
				}
			  if (currentState.board[i][j]==currentState.blocked)
					b[i][j].setBackground(Color.black);
			  if (currentState.board[i][j]==currentState.token)
					b[i][j].setIcon(icon);
			} // for
	} // drawBoard


} // myFrame
