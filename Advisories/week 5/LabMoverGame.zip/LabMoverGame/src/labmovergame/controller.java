/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package labmovergame;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

class controller extends JFrame
{
	JButton up, down, left, right;
	state currentBoard;
	myHandler H = new myHandler();


	public controller(state board, String name, int X, int Y)
	{
		currentBoard = board;
		setLocation(X, Y);
		setSize(150, 150);
		setTitle(name);

		Container c = getContentPane();
		c.setLayout(new BorderLayout());
		up = new JButton("up");
		up.addActionListener(H);
		c.add(up, "North");
		down = new JButton("down");
		down.addActionListener(H);
		c.add(down, "South");
		left = new JButton("left");
		left.addActionListener(H);
		c.add(left, "West");
		right = new JButton("right");
		right.addActionListener(H);
		c.add(right, "East");

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);

	} // constructor


	private class myHandler implements ActionListener
	{
		public void actionPerformed(ActionEvent e)
		{
			Object ob = e.getSource();
			if (ob == up)
				currentBoard.moveup();
			if (ob == down)
				currentBoard.movedown();
			if (ob == left)
				currentBoard.moveleft();
			if (ob == right)
				currentBoard.moveright();

		} // method actionPerformed

	} // myHandler

} // controller class
