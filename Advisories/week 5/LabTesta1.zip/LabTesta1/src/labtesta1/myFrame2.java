/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package labtesta1;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

class myFrame2 extends JFrame
{
	JButton[] b;	   // an array of buttons - though not yet created.
	my_handler H = new my_handler();


	public myFrame2()
	{
		setSize(200, 200);
		setTitle("Array Test");
		setLocation(300, 0);

		Container c = getContentPane();
		c.setBackground(Color.blue);
		c.setLayout(new GridLayout(5,1));

    	b = new JButton[5];     // Creates space for 3 buttons, but not the buttons themselves

		/* Create each button in turn, add an ActionListener to it, and add it to the frame */

    for (int i=0; i<5;i++)
		{
		  b[i] = new JButton("Name "+i);
		  b[i].addActionListener(H);
		  c.add(b[i]);
		} // for

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);

	} // myFrame2 constructor


	class my_handler implements ActionListener
	{
		public void actionPerformed(ActionEvent e)
		{
			Object ob = e.getSource();

			/* Test each button b[i] in turn to see if it generated the event */
			for (int i=0; i<5; i++)
			  if (ob == b[i])
				   System.out.println("[Array version]     Name "+i+" pressed");

		} // method actionPerformed

	} // class my_handler

} // myFrame2 class
