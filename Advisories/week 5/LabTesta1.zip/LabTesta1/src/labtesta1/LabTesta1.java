/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package labtesta1;
import java.awt.*;

/**
 *
 * @author ioneill
 */
public class LabTesta1 {

    /**
     * @param args the command line arguments
     */
    public static void main (String args[])
	{
		myFrame1 f1 = new myFrame1();
		myFrame2 f2 = new myFrame2();
	} // main

}
