/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package labtesta1;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

class myFrame1 extends JFrame
{
	JButton b0, b1, b2, b3, b4;
	myHandler H = new myHandler();


	public myFrame1()
	{
		setSize(200, 200);
		setTitle("Non-Array Version");
		setLocation(0, 0);

		Container c = getContentPane();
		c.setBackground(Color.blue);
		c.setLayout(new GridLayout(5,1));

		b0 = new JButton("Name 0");
		b0.addActionListener(H);
		c.add(b0);

		b1 = new JButton("Name 1");
		b1.addActionListener(H);
		c.add(b1);

		b2 = new JButton("Name 2");
		b2.addActionListener(H);
		c.add(b2);

		b3 = new JButton("Name 3");
		b3.addActionListener(H);
		c.add(b3);

		b4 = new JButton("Name 4");
		b4.addActionListener(H);
		c.add(b4);

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);

	} // myFrame1 constructor


	private class myHandler implements ActionListener
	{
		public void actionPerformed(ActionEvent e)
		{
			Object ob = e.getSource();

		  if (ob == b0)
		  		System.out.println("[Non-Array version] Name 0 pressed");
		  else if (ob == b1)
				System.out.println("[Non-Array version] Name 1 pressed");
			else if (ob == b2)
				System.out.println("[Non-Array version] Name 2 pressed");
			else if (ob == b3)
				System.out.println("[Non-Array version] Name 3 pressed");
			else if (ob == b4)
				System.out.println("[Non-Array version] Name 4 pressed");
		} // method actionPerformed

	} // myHandler

} // myFrame1
