/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package labtesta3;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

class myFrame extends JFrame
{
	JButton[][] b;
	int numX, numY;
	state currentState;
	myHandler H = new myHandler();


	public myFrame(int x, int y, state St)
	{
		numX = x;
		numY = y;
		currentState = St;

		setSize(100*x, 100*y);
		setTitle("Button Grid");

		Container c = getContentPane();
		c.setLayout(new GridLayout(numX, numY));

                b = new JButton[x][y];
                for (int i=0; i<numX;i++)
			for (int j=0; j<numY; j++)
			{
			  b[i][j] = new JButton(""+(i+1)+","+(j+1));
				b[i][j].setBackground(Color.lightGray);
		 		b[i][j].addActionListener(H);
		  	c.add(b[i][j]);
			} // for

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(300, 260);
		setVisible(true);

	} // myFrame constructor


	private class myHandler implements ActionListener
	{
		public void actionPerformed(ActionEvent e)
		{
			Object ob = e.getSource();

			// Test each possible button until the source is found
			for (int i=0; i<numX; i++)
				for (int j=0; j<numY; j++)
		  		if (ob == b[i][j])
		  		{
			  		System.out.print("Button "+(i+1)+","+(j+1)+" pressed.  ");
						if (!currentState.getState(i, j)) // was not already set - set it
						{
							currentState.setState(i, j, true);
				  		System.out.println("Now set");
							b[i][j].setBackground(Color.red);
                                                        //Toolkit.getDefaultToolkit().beep();
						}
						else // was already set - unset it
						{
							currentState.setState(i, j, false);
				  		System.out.println("Now unset");
							b[i][j].setBackground(Color.lightGray);
						} // else

		  		} // if

		} // method actionPerformed

	} // myHandler

} // myFrame
