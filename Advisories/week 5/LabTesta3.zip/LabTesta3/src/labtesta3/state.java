/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package labtesta3;

class state
{
	/* A position [i][j] is either pressed or not pressed */

	private boolean[][] pressed;

	public state(int numX, int numY)
	{
		pressed = new boolean[numX][numY];
		for (int i=0; i<numX; i++)
			for (int j=0; j<numY; j++)
				pressed[i][j] = false;
	} // constructor


	public void setState(int x, int y, boolean newState)
	{
		pressed[x][y] = newState;
	} // setState


	public boolean getState(int x, int y)
	{
		return pressed[x][y];
	} // getState


} // state
