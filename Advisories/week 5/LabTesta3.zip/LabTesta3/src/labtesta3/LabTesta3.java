/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package labtesta3;

/**
 *
 * @author ioneill
 */
public class LabTesta3 {

    /**
     * @param args the command line arguments
     */
    public static void main (String args[])
{
	state S = new state(3,3);
	myFrame f = new myFrame(3, 3, S);
} // main

}
