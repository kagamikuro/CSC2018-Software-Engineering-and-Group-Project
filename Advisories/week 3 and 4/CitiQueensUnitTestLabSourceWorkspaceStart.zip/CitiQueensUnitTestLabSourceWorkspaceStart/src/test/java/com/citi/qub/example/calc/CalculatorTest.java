package com.citi.qub.example.calc;

import org.junit.Assert;

import org.junit.Before;
import org.junit.Test;

public class CalculatorTest {

	Calculator calc;
	
	
	// the 'Before' annotation makes junit call this method before running each of the methods with the 'Test' annotation
	
	@Before
	public void createCalculator() {
		calc = new CalcImpl();
	}
	
	// ====================================================
	//     On/Off tests
	//  ==================================================== 
	
	/**
	 * This method tests that the calculator is off initially. 
	 * The '@Before' method is called by junit before every @Test method is called.
	 * As our '@Before' constructs the calculator, it should be off when we test here. 
	 */
	@Test
	public void testCalcIfOffInitially() {
		Assert.assertFalse(calc.isOn());
	}
	@Test
	public void testCalcSwitchOn() throws InvalidCalcKeyException { 
		calc.switchOn();
		Assert.assertTrue(calc.isOn());
		// lets be a bit paranoid and test that other operations, even hitting 'on' twice,  don't switch it off again..
		calc.switchOn();
		Assert.assertTrue(calc.isOn());
		calc.keyPressed('0');
		Assert.assertTrue(calc.isOn());		
	}

	@Test
	public void testCalcSwitchOff() throws InvalidCalcKeyException { 
		calc.switchOn();
		Assert.assertTrue(calc.isOn());
		// lets be a bit paranoid and test that other operations, even hitting 'off' twice,  don't switch it on again..
		calc.switchOff();
		Assert.assertFalse(calc.isOn());
		calc.keyPressed('0');
		Assert.assertFalse(calc.isOn());		
	}
	
	@Test
	public void displayBlankWhenSwitchedOn() throws InvalidCalcKeyException {
		calc.switchOn();
		Assert.assertEquals("", calc.getCurrentlyDisplayed());
		// again a paranoid test - press a key, switch off, switch on, validate blank display
		calc.keyPressed('1');
		calc.switchOff();
		calc.switchOn();
		Assert.assertEquals("", calc.getCurrentlyDisplayed());
	}
	
	@Test
	public void testBasicNumberInput() throws InvalidCalcKeyException {
		calc.switchOn();
		calc.keyPressed('4');
		calc.keyPressed('2');
		Assert.assertEquals("42", calc.getCurrentlyDisplayed());
	}
	
	@Test(expected=InvalidCalcKeyException.class)
	public void testInvalidInput() throws InvalidCalcKeyException {
		calc.switchOn();
		calc.keyPressed('Z');
		
		//  Junit effectively treats this as 
		//  try {
		//		calc.keyPressed('Z');
		//		Assert.fail("Expected InvalidCalcKeyExcpetion");
		//  }catch(InvalidCalcKeyExcpetion icke) {}
		
	}
	
	@Test
	public void testSimpleAddition() throws InvalidCalcKeyException {
		calc.switchOn();
		calc.keyPressed('4');
		calc.keyPressed('2');
		calc.keyPressed('+');
		calc.keyPressed('5');
		calc.keyPressed('8');
		calc.keyPressed('=');
		Assert.assertEquals("100", calc.getCurrentlyDisplayed());
	}
	
	/* Unit Testing exercise A - add a test for the 'clear' operation */

	
	/* Unit Testing  exercise B - add a test for subtraction */

	
	/* Unit testing exercise C - add tests for the memory function */


	/* Unit testing exercise D - add a test for multiplication and then implement in CalcImpl.java */
	

}	


