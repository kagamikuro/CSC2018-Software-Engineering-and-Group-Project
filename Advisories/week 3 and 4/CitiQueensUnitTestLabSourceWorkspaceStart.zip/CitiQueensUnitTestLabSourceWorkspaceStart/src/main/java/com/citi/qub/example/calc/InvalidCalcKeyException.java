package com.citi.qub.example.calc;

@SuppressWarnings("serial")
public class InvalidCalcKeyException extends Exception {
	
	public InvalidCalcKeyException(char c) {
		super("The key '" + c + "' is not known.");
	}

}
