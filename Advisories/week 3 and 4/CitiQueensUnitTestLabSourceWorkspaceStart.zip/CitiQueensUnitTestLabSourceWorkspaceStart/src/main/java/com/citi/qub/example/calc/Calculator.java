package com.citi.qub.example.calc;

public interface Calculator {
	
	
	
	public void switchOn();
	
	public void switchOff();
	
	public boolean isOn();
	
	public String getCurrentlyDisplayed();
	
	public void keyPressed(char key) throws InvalidCalcKeyException;
	
	

}
