package com.citi.qub.example.calc;

public class CalcImpl implements Calculator {
	
	private boolean on;
	private Long currentNumber;
	private Long lastNumber;
	private Long memNumber;
	private static enum Operation {
		ADD,
		SUBTRACT,
		/*MULTIPLY
		DIVIDE*/
	}
	Operation currentOp;
	
	
	public CalcImpl() {
		reset();
	}

	@Override
	public void switchOn() {
		on = true;
	}

	@Override
	public void switchOff() {
		reset();
	}

	private void reset() {
		on = false;
		currentNumber=null;
		lastNumber=null;
	}
	
	@Override
	public boolean isOn() { 
		return on;
	}

	@Override
	public String getCurrentlyDisplayed() {
		return currentNumber==null ? "" : currentNumber.toString();
	}

	@Override
	public void keyPressed(char key) throws InvalidCalcKeyException {
		
		// do nothing if switched off
		if(!on) {
			return;
		}
		
		if(Character.isDigit(key)) { 
			processInputDigit(key);
		}else{
			switch(key) {
			case  'C' : 
					clear();
					break;
			case	'=' : 
					calculate();
					break;
				case '+' :
					processAddition();
					break;
// Uncomment for lab exercise B					
/*				
				case '-' :
 					processSubtraction();
					break;
*/					
				case 'S' : 
					memStore();
					break;
				case 'R' : 
					memRetrieve();
					break;
				default : 
					throw new InvalidCalcKeyException(key);
			}	
		}
	}
	
	private void processInputDigit(char key) {
		long digit = Long.parseLong(Character.toString(key));
		if(currentNumber==null) {  
			currentNumber = digit;
		}else{
			currentNumber = currentNumber * 10 + digit;
		}
	}

	private void clear() {
		currentNumber=0L;
	}

	private void calculate() {
		switch(currentOp) {
		case ADD : 
			currentNumber += lastNumber;
			break;
// Uncomment for lab exercise B	
/*			
		case SUBTRACT :
			currentNumber = lastNumber-currentNumber;
			break;
*/			
		}
		 
			
		
	}

	private void processAddition() {
		if(currentNumber==null) { 
			lastNumber=  0L;
		}else{
			lastNumber=currentNumber;
		}
		currentNumber=0L;
		currentOp = Operation.ADD;
	}

//	Uncomment for lab exercise B
/*	
	private void processSubtraction() {
		if(currentNumber==null) { 
			lastNumber=  0L;
		}else{
			lastNumber=currentNumber;
		}
		currentNumber=0L;
		currentOp = Operation.SUBTRACT;
	}
*/

	
	private void memStore() {
		memNumber=currentNumber;
	}

	private void memRetrieve() {
		currentNumber=memNumber;
	}

}
