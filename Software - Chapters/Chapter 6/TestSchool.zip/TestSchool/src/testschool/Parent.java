/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package testschool;

/**
 *
 * @author ioneill
 */
public class Parent
{	private String parentName;

	public void setParentName(final String pname)
	{ parentName = pname;
	}

	public String getParentName()
	{return parentName;
	}
}
