/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package testschool;

/**
 *
 * @author ioneill
 */
public interface TeacherInterface {

	public void setTeacherName(final String pname);
	public String getTeacherName();
}
