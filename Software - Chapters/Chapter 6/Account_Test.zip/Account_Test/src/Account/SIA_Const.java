/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Account;

/**
 *
 * @author ioneill
 */
public class SIA_Const {
public static final double R1 = 0.00026116; //10%
public static final double R2 = 0.00028596; //11%
}
