/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Account;

/**
 *
 * @author ioneill
 */
abstract class Abstract_Account {
    abstract public String statement();
    abstract double account_balance ();
}
