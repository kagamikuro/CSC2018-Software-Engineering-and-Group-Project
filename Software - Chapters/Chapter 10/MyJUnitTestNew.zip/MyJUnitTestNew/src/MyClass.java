
public class MyClass {

	public int multiply(int x, int y){
		return x * y;
	}

}
